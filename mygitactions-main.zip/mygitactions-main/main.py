def hello():
    print("hi")


def bye():
    print("bye")


print(hello())
